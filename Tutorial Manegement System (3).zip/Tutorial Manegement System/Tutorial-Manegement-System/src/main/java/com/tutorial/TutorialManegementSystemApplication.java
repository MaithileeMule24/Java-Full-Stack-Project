package com.tutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TutorialManegementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TutorialManegementSystemApplication.class, args);
	}

}
